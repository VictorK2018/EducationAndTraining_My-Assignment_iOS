//
//  HistoryView.m
//  myAssignment_1
//
//  Created by Viktor on 2018-07-16.
//  Copyright © 2018 macuser. All rights reserved.
//

#import "HistoryView.h"

@interface HistoryView ()

@end

@implementation HistoryView

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

// set up table
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.histTable.count;
}

// set up cell content
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"historyCell" forIndexPath:indexPath];
    
    // Configure the cell...
    
    // show Item name
    cell.textLabel.text =
    [[_histTable objectAtIndex:indexPath.row]itemName] ;
    
    // show transaction quantity for Item
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%lu", (unsigned long)[[_histTable objectAtIndex:indexPath.row]purchQuant]];
    
    return cell;
}

    // create unwind segue method to come back from HistoryDetail
- (IBAction)backHistView:(UIStoryboardSegue*)segue{
    [self dismissViewControllerAnimated:YES completion:nil];
}

    //do a little preparation before navigation

# pragma mark - PrepareForSegue method

// prepare data before transition to HistoryDetail controller
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
     
     if ([segue.identifier isEqualToString:@"toDetail"]) {
     
     // create destination controller
     HistoryDetail *vc = (HistoryDetail*)[segue destinationViewController];
     
     // create index for selected row from table
     NSIndexPath *selectedIndex = [self.tableView indexPathForSelectedRow];
     
     // set up value to new Model object from selected row
     MyModel *buyItemAtselectedIndex = [self.histTable objectAtIndex:selectedIndex.row];
     
     // assign value from choosen Model object to HistoryDetail property
     vc.thisBuyItem = buyItemAtselectedIndex;
    }
     
 }

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

@end
