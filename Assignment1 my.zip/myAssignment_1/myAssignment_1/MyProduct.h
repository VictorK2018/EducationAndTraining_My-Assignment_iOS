//
//  MyProduct.h
//  myAssignment_1
//
//  Created by Viktor on 2018-07-21.
//  Copyright © 2018 macuser. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MyModel.h"

@interface MyProduct : NSObject

// list of Items
@property (nonatomic) NSMutableArray *itemList;

// history of purchased transactions
@property (nonatomic) NSMutableArray *historyList;

// calculation of purchased transaction and record data into 'historyList'
- (void)historySave:(int)index atQuant:(NSInteger)qnt;


@end
