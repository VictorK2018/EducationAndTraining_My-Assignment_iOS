//
//  MyModel.h
//  myAssignment_1
//
//  Created by Viktor on 2018-07-21.
//  Copyright © 2018 macuser. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyModel : NSObject

// Public properties

// Item's data
@property (nonatomic) NSString* itemName;
@property (nonatomic) double itemPrice;
@property (nonatomic) NSUInteger itemQuant;
@property (nonatomic) double totalSum;

// Purchase data
@property (nonatomic) NSUInteger purchQuant;
@property NSDate *purchTime;


//Public methods

// designated initializer (like c# constructor)
- (instancetype) initWithName:(NSString*)iName Price: (double)iPrice AndQuant:(NSUInteger)iQuant;

// convert Item's data into string to show
- (NSString*)itemString;

// deduct purchased quantity for Item and calculate 'totalSum'
- (NSUInteger)buy:(NSInteger)quantDeduct;

// add Item's quantity
- (NSUInteger)reStock: (NSUInteger)quantRestock;

// return purchase date
- (NSString*)buyDate;

@end

