//
//  HistoryDetail.h
//  myAssignment_1
//
//  Created by Viktor on 2018-09-10.
//  Copyright © 2018 macuser. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MyModel.h"
#import "HistoryView.h"

@interface HistoryDetail : UIViewController

// show details of each Item's transactions
@property (weak, nonatomic) IBOutlet UITextField *name;
@property (weak, nonatomic) IBOutlet UITextField *quantity;
@property (weak, nonatomic) IBOutlet UITextField *total;
@property (weak, nonatomic) IBOutlet UITextField *purchDate;

// 'Model' object to keep transaction details
@property (nonatomic) MyModel *thisBuyItem;

// button to return back to HistoryView
@property (weak, nonatomic) IBOutlet UIButton *buttDone;

@end
