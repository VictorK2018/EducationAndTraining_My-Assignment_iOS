//
//  ManagerView.h
//  myAssignment_1
//
//  Created by Viktor on 2018-10-22.
//  Copyright © 2018 macuser. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CashRegister.h"
#import "MyProduct.h"
#import "Restock.h"

NS_ASSUME_NONNULL_BEGIN

@interface ManagerView : UIViewController

// data for HistoryView
@property (strong, nonatomic)
NSMutableArray *buyList;

// data for RestockView
@property (strong, nonatomic)
NSMutableArray *restockList;

@end

NS_ASSUME_NONNULL_END
