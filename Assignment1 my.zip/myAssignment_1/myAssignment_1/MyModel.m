//
//  MyModel.m
//  myAssignment_1
//
//  Created by Viktor on 2018-07-21.
//  Copyright © 2018 macuser. All rights reserved.
//

#import "MyModel.h"

@implementation MyModel

- (instancetype) initWithName:(NSString*)iName Price:(double)iPrice AndQuant:(NSUInteger)iQuant

{ self = [super init];
    if (self) {
        // All initializations:
        _itemName = iName;
        _itemPrice = iPrice;
        _itemQuant = iQuant;
    }
    return self;
}

-(NSString*)itemString{
    
    //  limitation of digits shown after the point -> %.2f;
    return [NSString stringWithFormat:@"%@ %lu price(each): %.2f", self.itemName, (unsigned long)self.itemQuant, self.itemPrice];
}

- (NSUInteger)buy:(NSInteger)qntDeduct{
    
        // calculation 'Total'
        self.totalSum = self.itemPrice*qntDeduct;
      
        // set up quantity left in Stock
        self.itemQuant = self.itemQuant - qntDeduct;
        
        // set up 'Buy history' quantity
        self.purchQuant = qntDeduct;
      
        return  self.itemQuant;
    
}

- (NSUInteger)reStock:(NSUInteger)quantAdd{
    
        self.itemQuant = self.itemQuant + quantAdd;
    
    return self.itemQuant;
}

- (NSString*)buyDate {
    
    NSDate *purchDate = [NSDate date];
    
    // convert string into date
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
    [dateFormat setDateFormat:@"EEEE, MMMM dd, yyyy, hh:mm:ss aaa, zzz"];
    //    dateFormat.dateStyle = kCFDateFormatterMediumStyle;
    //    dateFormat.timeStyle = kCFDateFormatterShortStyle;
    dateFormat.locale =[[NSLocale alloc]initWithLocaleIdentifier:@"en_US"];
    NSString *strDate = [dateFormat stringFromDate:purchDate];
    
    return [NSString stringWithFormat:@"%@", strDate];
}

@end
