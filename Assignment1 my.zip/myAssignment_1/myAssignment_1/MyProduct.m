//
//  MyProduct.m
//  myAssignment_1
//
//  Created by Viktor on 2018-07-21.
//  Copyright © 2018 macuser. All rights reserved.
//

#import "MyProduct.h"

@implementation MyProduct

// creation list of Items to work with
- (NSMutableArray *)itemList{
    if (! _itemList){
        
        _itemList = [[NSMutableArray alloc] initWithObjects:
                    
                    [[MyModel alloc]initWithName:@"pants" Price:1.0 AndQuant:1],
                    
                    [[MyModel alloc]initWithName:@"shirt" Price:2.0 AndQuant:2],
                    
                    [[MyModel alloc]initWithName:@"dress" Price:3.0 AndQuant:3],
                    
                    [[MyModel alloc]initWithName:@"T-shirt" Price:9.99 AndQuant:5],
                    
                    [[MyModel alloc]initWithName:@"suites" Price:2099.99 AndQuant:10],
                    
                    [[MyModel alloc]initWithName:@"jeans" Price:9.99 AndQuant:15],
                    
                    [[MyModel alloc]initWithName:@"shorts" Price:29.99 AndQuant:20],
                    
                    [[MyModel alloc]initWithName:@"shoes " Price:300.99 AndQuant:50],
                    nil];
    }
    return _itemList;
}

// set up 'buy click' counter for start
NSInteger click = 0;

- (void)historySave:(int)index atQuant:(NSInteger)qnt {

    // increment 'buy click'
    click += 1;
    //    NSLog(@" this is 'BUY' click #: %li", (long)click);
    
    // set up to keep purchased transactions recorded, while changing rows
    if (click == 1) {
            _historyList = [NSMutableArray new];
        }
        
    // create temp object with data for selected Item
    MyModel *tempBuy = [self.itemList objectAtIndex:index];
    
    // create object to save data of purchased transaction
    MyModel *copyBuy = [MyModel new];
    
    //condition only for valid purchases
    if ( [[self.itemList objectAtIndex:index]itemQuant] >= qnt ){
        
        // implement 'buy' method to temp object
        [tempBuy buy:qnt];
    
        // set up data to copy - if 'buy click' happend on the same row
        copyBuy.itemName = tempBuy.itemName;
        copyBuy.itemPrice = tempBuy.itemPrice;
        copyBuy.itemQuant = tempBuy.itemQuant;
        copyBuy.totalSum = tempBuy.totalSum;
        copyBuy.purchQuant = tempBuy.purchQuant;
        copyBuy.purchTime = tempBuy.purchTime;
    
        // add purchased data/object to the 'historyList'
        [_historyList addObject:copyBuy];
    
    }
   
    else {
        tempBuy.totalSum = 0;
        
        NSLog(@"'buy' in Product: Not enough quantity in stock!");
    }
    
}

@end
