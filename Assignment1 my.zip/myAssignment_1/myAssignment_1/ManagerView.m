//
//  ManagerView.m
//  myAssignment_1
//
//  Created by Viktor on 2018-10-22.
//  Copyright © 2018 macuser. All rights reserved.
//

#import "ManagerView.h"

@interface ManagerView ()

@end

@implementation ManagerView

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}

 -(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
     
    // preparation before navigation to HistoryView
     if ([segue.identifier isEqualToString:@"toHistory"]) {
        
    // create destination controller
    HistoryView *vc = (HistoryView*)[segue destinationViewController];
 
    // set up value from ManagerView
    vc.histTable = self.buyList;
         
    }
 
    // preparation before navigation to Restock
    if ([segue.identifier isEqualToString:@"toRestock"]) {
        
    // create destination controller
    Restock *vc = (Restock*)[segue destinationViewController];
        
    // set up value from ManagerView
    vc.restockItemList = self.restockList;
    }
     
 }


@end
