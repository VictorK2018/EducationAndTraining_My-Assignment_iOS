//
//  Restock.m
//  myAssignment_1
//
//  Created by Viktor on 2018-09-15.
//  Copyright © 2018 macuser. All rights reserved.
//

#import "Restock.h"

@interface Restock ()

@end

@implementation Restock

#pragma mark - Methods of UIController's life cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
     // set up button's round corner
     self.cancel.layer.cornerRadius = 10;
     self.okey.layer.cornerRadius = 10;
    
}

- (void)viewWillAppear:(BOOL)animated{
     //reload data
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - Table view data source

// set up table
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _restockItemList.count;
}

// set up cell content
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"restockCell" forIndexPath:indexPath];
    
    // Configure the cell...
    
    // assign and show Item's data in this cell
    cell.textLabel.text = [[self.restockItemList
      objectAtIndex:indexPath.row] itemString] ;
    
    return cell;
}

    // select cell
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    // move data from choosen cell to the cell on the Table top
    [tableView moveRowAtIndexPath:indexPath toIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    
    // exchange data from this cell to the cell on the Table top
    [_restockItemList exchangeObjectAtIndex:indexPath.row withObjectAtIndex:0];

    // deque cells
    [tableView dequeueReusableCellWithIdentifier:@"restockCell" forIndexPath:indexPath];
    
    // show Item name in navigaion Bar's title in this View controller
    self.navigationItem.title = [[self.restockItemList
      objectAtIndex:0]itemName];
    
    // set up Item value from cell to Model object
    self.restockItem = [self.restockItemList
                        objectAtIndex:0];
    
    // update TableView instantly
    [tableView reloadData];
}

#pragma mark - IBAction's methods

- (IBAction)addQuant:(id)sender {
    
    // get new Item's quantity after this button pressed
    [self.restockItem  reStock:[_quantRestock.text integerValue]];
    
    // update TableView instantly
    [self.restockTable reloadData];
    
}

- (IBAction)cancelButton:(id)sender {
    
    // clean 'quantRestock' label's text
    [_quantRestock setText:@""];
    
    // hide keyboard after pressing this button
    [_quantRestock resignFirstResponder];
}

@end
