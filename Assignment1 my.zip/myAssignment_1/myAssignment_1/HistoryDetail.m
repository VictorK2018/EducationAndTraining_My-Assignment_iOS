//
//  HistoryDetail.m
//  myAssignment_1
//
//  Created by Viktor on 2018-09-10.
//  Copyright © 2018 macuser. All rights reserved.
//

#import "HistoryDetail.h"

@interface HistoryDetail ()

@end

@implementation HistoryDetail

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // set up button's round corner
     _buttDone.layer.cornerRadius = 12;
    
    // assign values for labels from 'Model' object
    self.name.text = self.thisBuyItem.itemName;
    self.quantity.text = [NSString stringWithFormat: @"%lu", (unsigned long) self.thisBuyItem.purchQuant];
    self.total.text = [NSString stringWithFormat:@"%.2f", self.thisBuyItem.totalSum];
    self.purchDate.text = [self.thisBuyItem buyDate];

    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

 #pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
//- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
//  Get the new view controller using
//    [segue destinationViewController]

//  Pass the selected object to the new view controller.
    
//}

@end
