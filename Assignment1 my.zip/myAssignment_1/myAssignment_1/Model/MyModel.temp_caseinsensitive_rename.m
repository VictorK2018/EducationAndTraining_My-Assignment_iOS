//
//  myModel.m
//  myAssignment_1
//
//  Created by Victor Kalininskiy on 2017-11-09.
//  Copyright © 2017 macuser. All rights reserved.
//

#import "MyModel.h"

@implementation MyModel

// calculation total summ
-(double)calculateBuy{
    
   _totalSum = [self  itemPrice] * [self itemQuant];
    
    return _totalSum;
        
    return 0;
}


// designated initializer (like c# constructor)
 - (instancetype) initWithName:(NSString*)iName Price:(double)iPrice AndQuant:(NSUInteger)iQuant
{
    self = [super init];
    if (self) {
    // All initializations:
        _itemName = iName;
        _itemPrice = iPrice;
        _itemQuant = iQuant;
    }
    return self;
}

// convert Item's result into string to show
-(NSString*)ItemString{
    
//  limitation shown digits after the point
//     -> %.2f;
    return [NSString stringWithFormat:@"%@ %lu price (each):%.2f", self.itemName, (unsigned long)self.itemQuant, self.itemPrice];
}

// convert Buy's result into string to show
-(NSString*)BuyString {
    
     NSDate *purchDate = [NSDate date];
    
    // convert string into date
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
    dateFormat.dateStyle = kCFDateFormatterMediumStyle;
    dateFormat.timeStyle = kCFDateFormatterShortStyle;
    dateFormat.locale =[[NSLocale alloc]initWithLocaleIdentifier:@"en_US"];
    NSString *strDate = [dateFormat stringFromDate:purchDate];
    
    return [NSString stringWithFormat:@"%@, Quantity to buy:%lu, Total:%.2f, PurchuesDate:%@", self.itemName, (unsigned long)self.itemQuant, self.totalSum, strDate];
}

@end
