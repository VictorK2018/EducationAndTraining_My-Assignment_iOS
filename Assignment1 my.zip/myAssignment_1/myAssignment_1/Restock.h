//
//  Restock.h
//  myAssignment_1
//
//  Created by Viktor on 2018-09-15.
//  Copyright © 2018 macuser. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CashRegister.h"
#import "HistoryView.h"
#import "MyModel.h"
#import "MyProduct.h"


@interface Restock : UIViewController
<UITableViewDelegate, UITableViewDataSource>

// show Item name
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

// show Items to be added
@property (weak, nonatomic) IBOutlet UITextField *quantRestock;

// 'Cancel' button
@property (weak, nonatomic) IBOutlet UIButton *cancel;

// 'OK' button
@property (weak, nonatomic) IBOutlet UIButton *okey;

// table to show Items in stock
@property (weak, nonatomic) IBOutlet UITableView *restockTable;

// list of Items in Stock
@property (nonatomic) NSMutableArray *restockItemList;

// 'Model' object to keep Item data
@property (nonatomic) MyModel *restockItem;

// action for button 'OK' - increase Item quantity by amount from 'nameLabel'
- (IBAction)addQuant:(id)sender;

// action for 'Cancel' button - disappear Keyboard
- (IBAction)cancelButton:(id)sender;

@end
