//
//  ViewController.h
//  myAssignment_1
//
//  Created by Victor Kalininskiy on 2017-11-09.
//  Copyright © 2017 macuser. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HistoryView.h"
#import "ManagerView.h"
#import "MyModel.h"
#import "MyProduct.h"

@interface CashRegister : UIViewController
<UIPickerViewDelegate, UIPickerViewDataSource>

// Public properties

// show total summ for purchased transaction
@property (weak, nonatomic) IBOutlet UILabel *total;

// show quantity to enter
@property (weak, nonatomic) IBOutlet UILabel *quantEnter;

// show Item's name
@property (weak, nonatomic) IBOutlet UILabel *itemNames;

// show list of Items
@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;

// button to initiate "buy' transaction
@property (weak, nonatomic) IBOutlet UIButton *buttBuy;

// show buttons with numbers:
@property (weak, nonatomic) IBOutlet UIButton *butt1;
@property (weak, nonatomic) IBOutlet UIButton *butt2;
@property (weak, nonatomic) IBOutlet UIButton *butt3;
@property (weak, nonatomic) IBOutlet UIButton *butt4;
@property (weak, nonatomic) IBOutlet UIButton *butt5;
@property (weak, nonatomic) IBOutlet UIButton *butt6;
@property (weak, nonatomic) IBOutlet UIButton *butt7;
@property (weak, nonatomic) IBOutlet UIButton *butt8;
@property (weak, nonatomic) IBOutlet UIButton *butt9;
@property (weak, nonatomic) IBOutlet UIButton *buttZero;

// access to MyProduct's Class data
@property (nonatomic) MyProduct *itemBuy;

// action for button 'buy' - initiate "buy' transaction
- (IBAction)buyItem:(id)sender;

// action when any button with numbers is pressed
- (IBAction)numbPressed:(id)sender;

@end

