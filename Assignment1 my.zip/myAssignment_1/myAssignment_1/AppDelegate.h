//
//  AppDelegate.h
//  myAssignment_1
//
//  Created by Victor Kalininskiy on 2017-11-09.
//  Copyright © 2017 macuser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

// set up for moving data over controllers
//@property (strong, nonatomic) NSMutableArray *buyList;
//@property (strong, nonatomic) NSMutableArray *restockList;

@end

