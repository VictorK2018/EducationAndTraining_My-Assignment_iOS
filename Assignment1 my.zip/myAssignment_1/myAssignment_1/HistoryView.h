//
//  HistoryView.h
//  myAssignment_1
//
//  Created by Viktor on 2018-07-16.
//  Copyright © 2018 macuser. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CashRegister.h"
#import "HistoryDetail.h"
#import "ManagerView.h"
#import "MyProduct.h"


@interface HistoryView : UITableViewController

// history of all transactions
@property (nonatomic) NSMutableArray *histTable;

@end
