//
//  ViewController.m
//  myAssignment_1
//
//  Created by Victor Kalininskiy on 2017-11-09.
//  Copyright © 2017 macuser. All rights reserved.
//

#import "CashRegister.h"

@implementation CashRegister


// Item's number in the list of Items
 int itemIndex;

// 'lazy' instantiation of Product's object
- (MyProduct*)itemBuy{
    if (! _itemBuy) {
        _itemBuy = [[MyProduct alloc]init];
    }
    return _itemBuy;
}

#pragma mark - Methods of UIController's life cycle

// called after Controller View is loaded into memory
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //set up button's round corner
    _buttBuy.layer.cornerRadius = 12;
    _butt1.layer.cornerRadius = 8;
    _butt2.layer.cornerRadius = 8;
    _butt3.layer.cornerRadius = 8;
    _butt4.layer.cornerRadius = 8;
    _butt5.layer.cornerRadius = 8;
    _butt6.layer.cornerRadius = 8;
    _butt7.layer.cornerRadius = 8;
    _butt8.layer.cornerRadius = 8;
    _butt9.layer.cornerRadius = 8;
    _buttZero.layer.cornerRadius = 8;
    
    // set up Item name for label
    self.itemNames.text = [[ self.itemBuy.itemList objectAtIndex:0]itemName];
    
//    NSLog(@"item name at CashRegister viewDidLoad: %@",  [[self.itemBuy.itemList objectAtIndex:0]itemName]);
//
//    NSLog(@"...and item quantity: %lu",  (unsigned long)[[self.itemBuy.itemList objectAtIndex:0]itemQuant]);
    
    // Do any additional setup after loading the view, typically from a nib.
}

// update this view when user goes back here
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
    // set up value inside labels
    self.total.text = @"";
    self.quantEnter.text = @"";
    
    // reload Picker View
    [self.pickerView reloadAllComponents];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Picker View's methods

// set up PickerView
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    //    return 8;
    return self.itemBuy.itemList.count;
}

// the delegate method that returns the content of every line
// Called by Picker View to use the title for given row
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    //create Model's object with Item's data from selected row
    MyModel *tempPointer1 = [self.itemBuy.itemList objectAtIndex:row];
    
    //return Item's data as a string
    return [tempPointer1 itemString];
}

// Called by Picker View when the user selects a row
- (void)pickerView:(UIPickerView *)pickerView
      didSelectRow:(NSInteger)row
       inComponent:(NSInteger)component{
    
    // set up Item's number
    itemIndex = (int)row;
    
    // set up values inside labels before calculation
    self.total.text = [NSString stringWithFormat:@""];
    
    self.quantEnter.text = @"";
    
    self.itemNames.text = [[ self.itemBuy.itemList objectAtIndex:row]itemName];
    
    //reload all components
    [self.pickerView reloadAllComponents];
}

#pragma mark - IBAction's methods

// enter and show quantity inside label by pressing numbers
- (IBAction)numbPressed:(id)sender {
    
    // assign entered quantity to text inside label
    self.quantEnter.text = [_quantEnter.text  stringByAppendingFormat:@"%@", [sender currentTitle]];
}

// process click to 'buy' button
- (IBAction)buyItem:(id)sender{
    
    //set condition only for valid purchases
    if ([self.quantEnter.text integerValue] != 0) {
        
    // ask 'historySave' method to this row's data
    [self.itemBuy historySave:itemIndex atQuant:[_quantEnter.text  integerValue]];
        
    // convert 'Total' string into text and assign to the text of Label
    self.total.text = [NSString stringWithFormat:@"%.2f", [[self.itemBuy.itemList objectAtIndex:itemIndex]totalSum]];
    
    // reload pickerView
    [self.pickerView reloadAllComponents];
        
    }
    
    // initiate Alert message if enter '0'
    else {
        UIAlertController *zeroAlert = [UIAlertController alertControllerWithTitle:@"Alert message" message:@"No/zero quantity to buy entered, please enter more!" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *defaulAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {}];
        [zeroAlert addAction:defaulAction];
        [self presentViewController:zeroAlert animated:YES completion:nil];
        
        // warning for entering '0'
        //    NSLog(@"please do not enter '0' !");
    }
    
}

# pragma mark - PrepareForSegue method

// prepare data before transition to Manager View Controller
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([segue.identifier isEqualToString:@"toManagerView"]) {
        
        // create destination View Controller
        ManagerView *vc = (ManagerView*)[segue destinationViewController];
        
        // set up value from here to Manager View Controller
        vc.buyList = self.itemBuy.historyList;
        vc.restockList = self.itemBuy.itemList;
    }
}

@end
