//
//  DetailSegue.h
//  myAssignment_1
//
//  Created by Viktor on 2018-09-11.
//  Copyright © 2018 macuser. All rights reserved.
//

#import <UIKit/UIKit.h>

// custom segue to open view as an animated book page
@interface DetailSegue : UIStoryboardSegue

@end
