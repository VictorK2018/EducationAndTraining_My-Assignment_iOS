//
//  DetailSegue.m
//  myAssignment_1
//
//  Created by Viktor on 2018-09-11.
//  Copyright © 2018 macuser. All rights reserved.
//

#import "DetailSegue.h"

@implementation DetailSegue

-(void) perform {
    UIViewController *source = self.sourceViewController;
    UIViewController *destination = self.destinationViewController;
        
    [UIView transitionFromView:source.view toView:destination.view duration:0.50f
            options:UIViewAnimationOptionTransitionCurlUp completion:^(BOOL finished){}];
}

@end
